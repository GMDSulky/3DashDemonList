# Welcome to the maintained Geometry Dash Shitty List repo!

# FAQ

---

### Website FAQ

Can I use the Shitty List template?

- I mean, sure. just make sure you give credit somewhere and make sure you state
  that you're not affiliated with the shitty list.

The website isnt loading! What can I do?

- since no webhost is perfect, downtime is expected. you can either wait til the
  website is back online or you can do some behind the scene stuff and run it
  locally.

---

### List FAQ

How long will my record take to get accepted?

- On a normal day it will take 0-48 hours for the record to be accepted,
  sometimes up to 72 hours, which may be slightly common, and if it ever is
  taking more than 72 hours, it will be announced that there is a backup of
  records or some site issues

What do New record, update record, and fix record mean?

- new record is when your submitting a record for a level for the first time,
  update record is when you have a record on a level but you got a new best and
  it needs to be updated, fix record is when there is an issue with one of your
  records that needs to be fixed

What's an easy way to prove I don't hack?

- Show 2-5 seconds at the end of the previous attempt and the death of that
  attempt. This is the easiest way for us to verify you arent hacking/nocliping.
  However having click, fps counter or hand cam will help out a lot too

It's been like more than a week and my record still hasn't been added, what do i
do?

- You can ask us in
  [#list-support](https://discord.com/channels/713151800932433972/744151240765603951)
  , it was probably an accidentally deleted record(yes it happens), accidentally
  deleting the form, your name was mispelled or you were rejected for cheating

When will \_\_\_ be added to the list?

- With the way our current system works, the staff and relaibles play the
  levels, if the level gets enough positive opinions from us, it then goes into
  voting, where it is voted on if it will be added

Can i submit Multiple levels on 1 video?

- Yes

---

## More Coming Soon!

# List Staff Team

---

## Owners:

- Bluestone
- JustCrust

---

## List Admins:

- Davine_007
- Acidius

## Server Administrators:

- Microwaveee

---

## List Helpers:

- Samuuu18
- KylashTheKiller
- TravelChimp
- Achlys
- homegrowntag
- asmallsock

---

## Server Moderators:

- LBoke
- frigusterio
- Prometheus
- Nolife
- Ryoui

---

## Repo Maintainers:

- Electro
- Prometheus
- Emonadeo
